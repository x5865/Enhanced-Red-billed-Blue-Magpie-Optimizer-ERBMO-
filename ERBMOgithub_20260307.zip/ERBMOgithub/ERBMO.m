function [BestValue, Xfood, Conv] = ERBMO(N, T, Xmin, Xmax, D, fobj)
% Initialize the relevant parameters
Xfood = zeros(1, D);
BestValue = inf;
Conv = zeros(1, T);
fitness = inf(N, 1);
Epsilon= 0.5; % Initial Epsilon
X = initialization(N, D, Xmax, Xmin);
X_old = X;
fitness_old = inf(N, 1);
for i = 1:N
    fitness_old(i, 1) = fobj(X_old(i, :));
end
t = 1; % Start of the main loop
alpha = 0.95; % Epsilon decay factor
beta = 0.05; % Factor for fitness improvement
gamma = 0.01; % Factor for population diversity
while t < T+1
    for i = 1:N
        % Randomly select 2 to 5 red-billed blue magpies
        p = randi([2, 5]);
        selected_index_p = randperm(N, p);
        Xp = X(selected_index_p, :);
        Xpmean = mean(Xp);
        % Randomly select 10 to N red-billed blue magpies
        q = randi([10,N]);
        selected_index_q = randperm(N, q);
        Xq = X(selected_index_q, :);
        Xqmean = mean(Xq);
        A = randperm(N);
        R1 = A(1);
        R2 = A(2);
        if rand < Epsilon
            X(i, :) =X(i, :) + (Xpmean - X(R1, :)) .* rand; % Eq. (3)
        else
            X(i, :) =X(i, :) + (Xqmean - X(R2, :)) .* rand; % Eq. (3); % Eq. (4)
        end
    end
    % Boundary handling
    X = boundaryCheck(X, Xmin, Xmax);
    for i = 1:N
        fitness(i, 1) = fobj(X(i, :));
        if fitness(i, 1) < BestValue
            BestValue = fitness(i, 1);
            Xfood = X(i, :);
        end
    end
    if rem(t,100)==0 && t~=0
        % delta=Calculate_step(X,fitness,Xfood);
        x_temp=patternsearch(Xfood,fobj,D,Xmin,Xmax);%Innovation 2: Periodic Pattern Search
        f_temp=fobj(x_temp);
        if f_temp<BestValue
            BestValue=f_temp;
            Xfood=x_temp;
        end
    end
    % Calculate population diversity
    diversity = std(fitness);
    % Calculate improvement in best fitness
    improvement = BestValue - min(fitness);
    CF = 0.8; % Initial Epsilon
    % Update Epsilon
    CF = alpha * CF + beta * (1 / (1 + improvement^rand)) + gamma * diversity;%Innovation 1: Diversity-based Adaptive Weight Update
    CF = max(min(CF, 1), 0); % Ensure Epsilon is between 0 and 1
    % % Food storage
    [fitness, X, fitness_old, X_old] = Food_storage(fitness, X, fitness_old, X_old);
    % Exploitation
    for i = 1:N
        if rand() < Epsilon
            X(i, :) = Xfood + CF * (Xpmean - X(i, :)) .* randn(1, D); % Eq. (5)
        else
            X(i, :) = Xfood + CF * (Xqmean - X(i, :)) .* randn(1, D); % Eq. (6)
        end
    end
    % Boundary handling
    X = boundaryCheck(X, Xmin, Xmax);
    for i = 1:N
        fitness(i, 1) = fobj(X(i, :));
        if fitness(i, 1) < BestValue
            BestValue = fitness(i, 1);
            Xfood = X(i, :);
        end
    end
    % Initial mutation rate and parameters to adjust the rate
    initialMutationRate = 0.1;
    mutationRateIncrease = 0.001; % Increase in mutation rate per generation
    maxMutationRate = 0.5; % Maximum mutation rate
    currentMutationRate = min(initialMutationRate + mutationRateIncrease * (t - 1), maxMutationRate);%Innovation 3: Evolutionary Probability-based Combinatorial Mutation
    pGaussian = 0.6; % Probability of Gaussian mutation
    sigma = 0.1; % Standard deviation for Gaussian mutation
    % Apply combined mutation
    for i = 1:N
        if rand() < currentMutationRate
            if rand() < pGaussian
                % Gaussian mutation
                X(i, :) = X(i, :) + sigma * randn(1, D);
            else
                % Uniform mutation
                X(i, :) = Xmin + (Xmax - Xmin) .* rand(1, D);
            end
        end
    end
    % Boundary handling after mutation
    X = boundaryCheck(X, Xmin, Xmax);
    for i = 1:N
        fitness(i, 1) = fobj(X(i, :));
        if fitness(i, 1) < BestValue
            BestValue = fitness(i, 1);
            Xfood = X(i, :);
        end
    end
    % Food storage
    [fitness, X, fitness_old, X_old] = Food_storage(fitness, X, fitness_old, X_old);
    Conv(t) = BestValue;
    t = t + 1;
end
end