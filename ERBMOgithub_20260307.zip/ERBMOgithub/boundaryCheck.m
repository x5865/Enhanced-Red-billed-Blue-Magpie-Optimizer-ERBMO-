
function X = boundaryCheck(X, Xmin, Xmax)
    for i = 1:size(X, 1)
        FU = X(i, :) > Xmax;
        FL = X(i, :) < Xmin;
        X(i, :) = (X(i, :) .* (~(FU + FL))) + Xmax .* FU + Xmin .* FL;
    end
end