%% Test of Improved RBMO Algorithm
clear all 
close all
clc

N = 30; % Number of search agents
dim = 30;
Function_name = 2; % Name of the test function, range from 1-30
iter = 500; % Maximum number of iteration times

% Load details of the selected benchmark function
[lb, ub, dim, fobj] = Get_Functions_cec2017(Function_name, dim);

%% Call single algorithm (ERBMO as example here)
[ERBMO_fvalbest, ERBMO_xposbest, ERBMO_Curve] = ERBMO(N, iter, lb, ub, dim, fobj);
display(['The best optimal value of the objective function found by ERBMO for ' num2str(Function_name) ' is : ', num2str(ERBMO_fvalbest)]);

% Figure - Convergence curve
figure(1)
CNT = 35;
k = round(linspace(1, iter, CNT)); % Randomly select CNT points
% Note: If the convergence curve shows too few points and the random points are sparse, 
% it means too few points are selected. In this case, increase the number of points 
% (e.g., 100, 200, 300, etc., gradually increase)
% Conversely, if the random points on the convergence curve are very dense, 
% it means too many points are selected, and you should reduce the number of points

iter_axis = 1:1:iter;
semilogy(iter_axis(k), ERBMO_Curve(k), 'color', [0.90,0.21,0.27], 'marker', 'p', 'linewidth', 1.5, 'MarkerSize', 8, 'MarkerFaceColor', [0.90,0.21,0.27]);
grid on;

title(['Convergence curve for F' num2str(Function_name)], 'FontSize', 12, 'FontWeight', 'bold');
xlabel('Iterations', 'FontSize', 11);
ylabel('Fitness value (log scale)', 'FontSize', 11);
box on;
legend('ERBMO', 'Location', 'northeast', 'FontSize', 11);
set(gcf, 'position', [300, 300, 800, 400]);
grid on;

