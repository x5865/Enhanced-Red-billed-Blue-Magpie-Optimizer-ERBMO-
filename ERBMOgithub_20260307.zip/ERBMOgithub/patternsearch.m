
function [newPosition] = patternsearch(currentPosition, objectiveFunction, numDimensions, lowerBounds, upperBounds)

identityMatrix = eye(numDimensions);
stepSize = 0.5;
tolerance = 1e-15;
reductionFactor = 0.5;
accelerationFactor = 1.2;
currentIndex = 1;
totalDimensions = numDimensions;
trialPosition = currentPosition;
while stepSize > tolerance
    while currentIndex <= totalDimensions
        trialValue1 = objectiveFunction(trialPosition + stepSize * identityMatrix(currentIndex,:));
        if trialValue1 < objectiveFunction(trialPosition)
            trialPosition = trialPosition + stepSize * identityMatrix(currentIndex,:);
            currentIndex = currentIndex + 1;
            continue;
        end
        
        trialValue2 = objectiveFunction(trialPosition - stepSize * identityMatrix(currentIndex,:));
        if trialValue2 < objectiveFunction(trialPosition)
            trialPosition = trialPosition - stepSize * identityMatrix(currentIndex,:);
            currentIndex = currentIndex + 1;
            continue;
        else
            currentIndex = currentIndex + 1;
        end
    end
    
    currentFunctionValue = objectiveFunction(trialPosition);
    if currentFunctionValue < objectiveFunction(currentPosition)
        previousPosition = currentPosition;
        currentPosition = trialPosition;
        trialPosition = currentPosition + accelerationFactor * (currentPosition - previousPosition);
        currentIndex = 1;
        continue;
    else 
        if stepSize <= tolerance
            break
        else
            stepSize = stepSize * reductionFactor;
            trialPosition = currentPosition;
            currentIndex = 1;
        end
    end
     
end

% Apply boundary control
for i = 1:numDimensions
    if currentPosition(i) < lowerBounds(i)
        currentPosition(i) = lowerBounds(i);
    end
    if currentPosition(i) > upperBounds(i)
        currentPosition(i) = upperBounds(i);
    end
end

newPosition = currentPosition;
end
